# Weekly Model Comparison

DAG ID: `weekly_model_comparison`

Start the Astro project:

```bash
astro dev start
```

Open http://localhost:8080 and sign in with `admin` / `admin`.
